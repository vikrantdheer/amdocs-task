package com.task3.restapiImpl.controller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class UserProfileControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @Value("${file.upload-dir}")
    private String uploadDir;

    private String userId;

    //@SneakyThrows
    @BeforeEach
    public void init() {
        userId = "vikrant";
        deleteExistingFiles();
    }

    @Test
    @WithMockUser(username = "vikrant")
    public void testUpdateProfilePicture() throws Exception {
        MockMultipartFile file = new MockMultipartFile("picture", "picture.png", MediaType.IMAGE_PNG_VALUE,
                "PROFILE PICTURE".getBytes());

        mockMvc.perform(MockMvcRequestBuilders.multipart("/api/v1/user-profile/{userId}/update-picture", userId)
                        .file(file)
                        .with(request -> {
                            request.setMethod("PUT");
                            return request;
                        })
                        .with(csrf()))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(username = "vikrant")
    public void testUpdateProfilePictureInvalidInput() throws Exception {
        MockMultipartFile file = new MockMultipartFile("picture", "", MediaType.IMAGE_PNG_VALUE, "".getBytes());

        mockMvc.perform(MockMvcRequestBuilders.multipart("/api/v1/user-profile/{userId}/update-picture", userId)
                        .file(file)
                        .with(request -> {
                            request.setMethod("PUT");
                            return request;
                        })
                        .with(csrf()))
                .andExpect(status().isBadRequest());
    }

    @Test
    @WithMockUser(username = "vikrant")
    public void testUpdateProfilePictureInvalidFileType() throws Exception {
        MockMultipartFile file = new MockMultipartFile("picture", "picture.pdf", MediaType.APPLICATION_PDF_VALUE,
                "PROFILE PICTURE".getBytes());

        mockMvc.perform(MockMvcRequestBuilders.multipart("/api/v1/user-profile/{userId}/update-picture", userId)
                        .file(file)
                        .with(request -> {
                            request.setMethod("PUT");
                            return request;
                        })
                        .with(csrf()))
                .andExpect(status().isBadRequest());
    }

    private void deleteExistingFiles() {
        try {
            Files.list(Paths.get(uploadDir)).forEach(file -> {
                try {
                    Files.delete(file);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            });
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}