package com.task3.restapiImpl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoftwareEnggTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
