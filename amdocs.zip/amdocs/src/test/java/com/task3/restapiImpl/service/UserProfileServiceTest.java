package com.task3.restapiImpl.service;

import com.task3.restapiImpl.exception.FileProcessingException;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class UserProfileServiceTest {

    @InjectMocks
    UserProfileService userProfileService;

    @Mock
    MultipartFile file;

    private String uploadDir;

    @BeforeEach
    public void init() {
        MockitoAnnotations.openMocks(this);
        uploadDir = "D:/workspace/self/amdocs/src/main/resources/uploads";
        userProfileService = new UserProfileService(uploadDir);
        deleteExistingFiles();
    }

    @Test
    @DisplayName("Test Update Profile Picture")
    public void testUpdateProfilePicture() throws Exception {
        String userId = "testUser";
        MockMultipartFile file = new MockMultipartFile("picture", "hello.png", "image/png",
                "test profile picture".getBytes());

        when(this.file.isEmpty()).thenReturn(false);
        when(this.file.getOriginalFilename()).thenReturn(file.getOriginalFilename());
        when(this.file.getInputStream()).thenReturn(file.getInputStream());

        boolean isUpdated = userProfileService.updateProfilePicture(userId, this.file);

        assertTrue(isUpdated);
        verify(this.file, times(1)).isEmpty();
        verify(this.file, times(1)).getOriginalFilename();
        verify(this.file, times(1)).getInputStream();
    }

    @Test
    @DisplayName("Test for updating profile picture with Empty User ID")
    public void testUpdateProfilePictureEmptyUserId() {
        String userId = StringUtils.EMPTY;
        MockMultipartFile file = new MockMultipartFile("picture", "hello.png", "image/png",
                "test image content".getBytes());

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            userProfileService.updateProfilePicture(userId, file);
        });

        String expectedMessage = "userId must not be null or blank";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    @DisplayName("Test for updating profile picture with Empty File")
    public void testUpdateProfilePictureEmptyFile() {
        String userId = "testUser";
        MockMultipartFile file = new MockMultipartFile("picture", "hello.png", "image/png",
                StringUtils.EMPTY.getBytes());

        Exception exception = assertThrows(FileProcessingException.class, () -> {
            userProfileService.updateProfilePicture(userId, file);
        });

        String expectedMessage = "Empty file";
        String actualMessage = exception.getMessage();

        assertTrue(actualMessage.contains(expectedMessage));
    }

    private void deleteExistingFiles() {
        try {
            Files.list(Paths.get(uploadDir)).forEach(file -> {
                try {
                    Files.delete(file);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            });
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}