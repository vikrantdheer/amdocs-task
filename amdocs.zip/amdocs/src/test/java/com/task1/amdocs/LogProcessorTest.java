package com.task1.amdocs;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class LogProcessorTest {

    private com.task1.amdocs.DocumentProcessingManagerImpl logProcessor;
    private com.task1.amdocs.StatisticsCalculator statisticsCalculator;
    private com.task1.amdocs.LogEntry logEntry;

    @BeforeEach
    void setUp() {
        logProcessor = new com.task1.amdocs.DocumentProcessingManagerImpl();
        statisticsCalculator = new com.task1.amdocs.StatisticsCalculator(logProcessor);
        logEntry = new com.task1.amdocs.LogEntry();
    }

    @Test
    void processLogLine() {
        List<com.task1.amdocs.LogEntry> logEntries = new ArrayList<>();

        //----------Document 1 - Genova_Paco_2
        creationOfDocument1(logEntries);

        //----------Document 2 - India_Paco_3
        creationOfDocument2(logEntries);

        //----------Document 3 - Genova_Vikrant_3
        creationOfDocument3(logEntries);

        //----------Document 4 - India_Vikrant_3
        creationOfDocument4(logEntries);

        for (com.task1.amdocs.LogEntry logEntry : logEntries) {
            logProcessor.processLogLine(logEntry);
        }

        /*//first three test cases are from document
        assertEquals(1, statisticsCalculator.getNumberOfDocumentsProcessed(2, 14, "Genova", "Paco"));
        assertEquals(2, statisticsCalculator.getNumberOfDocumentsProcessed(2, null, null, "Paco"));
        assertEquals(3, statisticsCalculator.getNumberOfDocumentsProcessed(3, 14, null, null));

        //my testing
        assertEquals(3, statisticsCalculator.getNumberOfDocumentsProcessed(3, null, null, null));
        assertEquals(2, statisticsCalculator.getNumberOfDocumentsProcessed(null, null, "India", null));*/
        assertEquals(5, statisticsCalculator.getNumberOfDocumentsProcessed(null, null, null, null));
    }

    private void creationOfDocument1(List<com.task1.amdocs.LogEntry> logEntries) {
        logEntries.addAll(List.of(
                new com.task1.amdocs.LogEntry("Genova", "Paco", 2, createTime("11:27:30.646"), "*********Starting scan********"),
                new com.task1.amdocs.LogEntry("Genova", "Paco", 2, createTime("11:27:31.646"), "Scan done. Image loaded in " +
                        "memory"),
                new com.task1.amdocs.LogEntry("Genova", "Paco", 2, createTime("11:27:32.646"), "Saving sample TIF image in " +
                        "share disc ..."),
                new com.task1.amdocs.LogEntry("Genova", "Paco", 2, createTime("11:27:33.646"), "Image TIF saved in shared disc"),
                new com.task1.amdocs.LogEntry("Genova", "Paco", 2, createTime("11:27:34.646"), "Loading image… "),
                new com.task1.amdocs.LogEntry("Genova", "Paco", 2, createTime("11:27:35.646"), "Image showed in applet"),
                //--------------------------------
                new com.task1.amdocs.LogEntry("Genova", "Paco", 2, createTime("14:27:30.646"), "*********Starting scan********"),
                new com.task1.amdocs.LogEntry("Genova", "Paco", 2, createTime("14:27:31.646"), "Scan done. Image loaded in memory"),
                new com.task1.amdocs.LogEntry("Genova", "Paco", 2, createTime("14:27:32.646"), "Saving sample TIF image in share disc " +
                        "..."),
                new com.task1.amdocs.LogEntry("Genova", "Paco", 2, createTime("14:27:33.646"), "Image TIF saved in shared disc"),
                new com.task1.amdocs.LogEntry("Genova", "Paco", 2, createTime("14:27:34.646"), "Loading image… "),
                new com.task1.amdocs.LogEntry("Genova", "Paco", 2, createTime("14:27:35.646"), "Image showed in applet")
        ));
    }

    private void creationOfDocument2(List<com.task1.amdocs.LogEntry> logEntries) {
        logEntries.addAll(List.of(
                new com.task1.amdocs.LogEntry("India", "Paco", 3, createTime("13:27:30.646"), "*********Starting scan********"),
                new com.task1.amdocs.LogEntry("India", "Paco", 3, createTime("13:27:31.646"), "Scan done. Image loaded in memory"),
                new com.task1.amdocs.LogEntry("India", "Paco", 3, createTime("13:27:32.646"), "Saving sample TIF image in share disc ." +
                        "." +
                        "."),
                new com.task1.amdocs.LogEntry("India", "Paco", 3, createTime("13:27:33.646"), "Image TIF saved in shared disc"),
                new com.task1.amdocs.LogEntry("India", "Paco", 3, createTime("13:27:34.646"), "Loading image… "),
                new com.task1.amdocs.LogEntry("India", "Paco", 3, createTime("13:27:35.646"), "Image showed in applet")
        ));
    }

    private void creationOfDocument3(List<com.task1.amdocs.LogEntry> logEntries) {
        logEntries.addAll(List.of(
                new com.task1.amdocs.LogEntry("Genova", "Vikrant", 3, createTime("14:27:30.646"), "*********Starting scan********"),
                new com.task1.amdocs.LogEntry("Genova", "Vikrant", 3, createTime("14:27:31.646"), "Scan done. Image loaded in memory"),
                new com.task1.amdocs.LogEntry("Genova", "Vikrant", 3, createTime("14:27:32.646"), "Saving sample TIF image in share disc " +
                        "..."),
                new com.task1.amdocs.LogEntry("Genova", "Vikrant", 3, createTime("14:27:33.646"), "Image TIF saved in shared disc"),
                new com.task1.amdocs.LogEntry("Genova", "Vikrant", 3, createTime("14:27:34.646"), "Loading image… "),
                new com.task1.amdocs.LogEntry("Genova", "Vikrant", 3, createTime("14:27:35.646"), "Image showed in applet")
        ));
    }

    private void creationOfDocument4(List<com.task1.amdocs.LogEntry> logEntries) {
        logEntries.addAll(List.of(
                new com.task1.amdocs.LogEntry("India", "Vikrant", 3, createTime("15:27:30.646"), "*********Starting scan********"),
                new com.task1.amdocs.LogEntry("India", "Vikrant", 3, createTime("15:27:31.646"), "Scan done. Image loaded in memory"),
                new com.task1.amdocs.LogEntry("India", "Vikrant", 3, createTime("15:27:32.646"), "Saving sample TIF image in share " +
                        "disc .." +
                        "."),
                new com.task1.amdocs.LogEntry("India", "Vikrant", 3, createTime("15:27:33.646"), "Image TIF saved in shared disc"),
                new com.task1.amdocs.LogEntry("India", "Vikrant", 3, createTime("15:27:34.646"), "Loading image… "),
                new com.task1.amdocs.LogEntry("India", "Vikrant", 3, createTime("15:27:35.646"), "Image showed in applet")
        ));
    }

    private LocalTime createTime(String time) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss.SSS");
        return LocalTime.parse(time, formatter);
    }

}