/*
package com.task2.amdocs;

import java.io.IOException;

public class RabbitMQTask {
    boolean autoAck = false;
    channel.basicConsume(queueName, autoAck, "a-consumer-tag", new DefaultConsumer(channel) {

        @Override
        public void handleDelivery (String consumerTag, Envelope envelope,
                                    AMQP.BasicProperties properties, byte[] body)
                throws IOException
        {
            long deliveryTag = envelope.getDeliveryTag();
            // positively acknowledge all deliveries up to
            // this delivery tag
            String message = new String(body, "UTF-8");
            Try {
            ApprovalRequestMessage approvalRequestMessage =
                    objectMapper.readValue(message, ApprovalRequestMessage.class);
            User user = userRepository.getUser(approvalRequestMessage.getUserId());
            ApprovalRequest approvalRequest = approvalRequestRepository.
                    getRequest(approvalRequestMessage.getRequestId())
            //invoking rule engine to validate request
            Evaluation evaluation = evaluateApprovalRequest(user.getCIF(),
                    approvalRequest.getBoundaries());
            If(evaluation.status().equals(”GREEN”)) {
                LOGGER.log(“Request approved.Request ID:
”,approvalRequestMessage.getRequestId()
                channel.basicAck(deliveryTag, true);
            }
else{
                LOGGER.log(“Request needs second evaluation.Request ID:
”,approvalRequestMessage.getRequestId()
            }
        }catch(Exeption e){
            LOGGER.log(“Technical issue”)
        }
        });
    }
*/
