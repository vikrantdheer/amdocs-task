package com.task3.restapiImpl.controller;

import com.task3.restapiImpl.service.UserProfileService;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping(value = "/api/v1/user-profile")
@CrossOrigin("http://localhost:8080")
@PreAuthorize("#userId == authentication.principal.username")
public class UserProfileController {

    private final UserProfileService userProfileService;

    public UserProfileController(UserProfileService userProfileService) {
        this.userProfileService = userProfileService;
    }

    @PutMapping(value = "/{userId}/update-picture", consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces =
            MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> updatePicture(@PathVariable String userId,
                                                @RequestPart("picture") MultipartFile picture) {

        try {
            if (userId.isBlank() || picture.isEmpty() || !isFileTypeValid(picture)) {
                return new ResponseEntity<>("Invalid input parameters", HttpStatus.BAD_REQUEST);
            }
            boolean isUpdated = userProfileService.updateProfilePicture(userId, picture);

            return isUpdated ? ResponseEntity.status(HttpStatus.OK).body("Profile picture updated successfully") :
                    ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to update profile picture");

        } catch (MaxUploadSizeExceededException e) {
            return ResponseEntity.status(HttpStatus.PAYLOAD_TOO_LARGE).body("File size exceeds limit");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to update profile picture");
        }
    }

    private boolean isFileTypeValid(MultipartFile picture) {
        String contentType = picture.getContentType();
        return contentType.equals(MediaType.IMAGE_JPEG_VALUE)
                || contentType.equals(MediaType.IMAGE_PNG_VALUE);
    }
}
