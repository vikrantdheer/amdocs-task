package com.task3.restapiImpl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoftwareEnggTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoftwareEnggTestApplication.class, args);
	}

}
