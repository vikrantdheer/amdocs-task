package com.task3.restapiImpl.service;

import com.task3.restapiImpl.exception.FileProcessingException;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Objects;

@Service
@Slf4j
@AllArgsConstructor
@RequiredArgsConstructor
public class UserProfileService {

    @Value("${file.upload-dir}")
    private String uploadDir;

    public boolean updateProfilePicture(String userId, MultipartFile picture) {
        Path destination = Paths.get(uploadDir)
                .resolve(Objects.requireNonNull(picture.getOriginalFilename()))
                .normalize().toAbsolutePath();
        try {
            if (userId.isBlank()) { //some db validation, checking same isBlank for now
                throw new IllegalArgumentException("userId must not be null or blank");
            }

            if (picture.isEmpty()) { //some other validation, checking same isEmpty for now
                throw new FileProcessingException("Empty file");
            }
            Files.copy(picture.getInputStream(), destination);
            return true;
        } catch (FileAlreadyExistsException e) {
            try {
                Files.delete(destination);
                Files.copy(picture.getInputStream(), destination);
                return true;
            } catch (IOException ex) {
                throw new RuntimeException("Could not update profile picture", ex);
            }
        } catch (IOException e) {
            throw new RuntimeException("Could not update profile picture", e);
        }
    }
}
