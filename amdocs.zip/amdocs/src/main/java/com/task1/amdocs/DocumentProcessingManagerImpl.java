package com.task1.amdocs;

import lombok.extern.slf4j.Slf4j;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class DocumentProcessingManagerImpl implements com.task1.amdocs.DocumentProcessingManager {
    private static final String STARTING_SCAN = "*********Starting scan********";
    private static final String SCAN_DONE = "Scan done. Image loaded in memory";
    private static final String SAVING_IMAGE = "Saving sample TIF image in share disc ...";
    private static final String IMAGE_SAVED = "Image TIF saved in shared disc";
    private static final String LOADING_IMAGE = "Loading image… ";
    private static final String IMAGE_SHOWED = "Image showed in applet";
    private static final String UNDERSCORE = "_";

    private Map<String, List<com.task1.amdocs.ProcessTime>> documents;

    public DocumentProcessingManagerImpl() {
        documents = new HashMap<>();
    }

    public void processLogLine(com.task1.amdocs.LogEntry logEntry) {
        String key =
                logEntry.getOfficeName() + UNDERSCORE + logEntry.getUserName() + UNDERSCORE + logEntry.getMonthDay() +
                        UNDERSCORE + "DocumentApp";
        List<com.task1.amdocs.ProcessTime> processList = documents.getOrDefault(key, new ArrayList<>());
        com.task1.amdocs.ProcessTime currentProcess = processList.isEmpty() ? new com.task1.amdocs.ProcessTime() :
                processList.get(processList.size() - 1);

        LocalTime timestamp = logEntry.getTimeInMilliseconds();

        String logString = logEntry.getLogString();
        if (STARTING_SCAN.equals(logString)) {
            currentProcess = new com.task1.amdocs.ProcessTime();
            currentProcess.setScanStartTime(timestamp);
            processList.add(currentProcess);
        } else if (SCAN_DONE.equals(logString)) {
            currentProcess.setScanEndTime(timestamp);
        } else if (SAVING_IMAGE.equals(logString)) {
            currentProcess.setSaveStartTime(timestamp);
        } else if (IMAGE_SAVED.equals(logString)) {
            currentProcess.setSaveEndTime(timestamp);
        } else if (LOADING_IMAGE.equals(logString)) {
            currentProcess.setLoadStartTime(timestamp);
        } else if (IMAGE_SHOWED.equals(logString)) {
            currentProcess.setLoadEndTime(timestamp);
        }

        documents.put(key, processList);
    }

    public Map<String, List<com.task1.amdocs.ProcessTime>> getDocuments() {
        return documents;
    }

}