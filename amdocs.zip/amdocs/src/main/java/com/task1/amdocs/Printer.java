package com.task1.amdocs;

public interface Printer {
    void printSummary(int count, long avgScanTime, long avgSaveTime, long avgLoadTime);

    void printDetails(String office, String userName, Integer day, Integer hour, int count, long avgScanTime,
                      long avgSaveTime, long avgLoadTime);
}
