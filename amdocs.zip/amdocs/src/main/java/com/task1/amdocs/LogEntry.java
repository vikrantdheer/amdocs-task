package com.task1.amdocs;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LogEntry {
    private String officeName;
    private String userName;
    private int monthDay;
    private LocalTime timeInMilliseconds;
    private String logString;

}
