package com.task1.amdocs;

import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
public class StatisticsCalculator {
    private com.task1.amdocs.DocumentProcessingManager logProcessorImplementation;

    private com.task1.amdocs.Printer reportPrinter;

    public StatisticsCalculator(com.task1.amdocs.DocumentProcessingManagerImpl logProcessor) {
        this.logProcessorImplementation = logProcessor;
    }

    public List<ProcessTime> calculateAverages(Integer day, Integer hour, String office, String userName) {
        Map<String, List<ProcessTime>> documents = logProcessorImplementation.getDocuments();

        List<ProcessTime> filteredProcesses = filterTheProcesses(day, hour, office, userName, documents);

        Map<String, List<ProcessTime>> groupedByCriteria = filteredProcesses.stream()
                .collect(Collectors.groupingBy(processTime -> processTime.getOffice() + "_" +
                        processTime.getUserName() + "_" + processTime.getDay() + "_" + processTime.getHour()));

        for (Map.Entry<String, List<ProcessTime>> entry : groupedByCriteria.entrySet()) {
            String[] keyParts = entry.getKey().split("_");
            String entryOffice = keyParts[0];
            String entryUserName = keyParts[1];
            int entryDay = Integer.parseInt(keyParts[2]);
            int entryHour = Integer.parseInt(keyParts[3]);

            if (hour != null && hour != entryHour) {
                continue;
            }

            List<ProcessTime> processesInGroup = entry.getValue();
            Map<String, Long> totalTimesAndAverages = calculateTotalTimesAndAverages(processesInGroup);

            printReport(entryOffice, entryUserName, entryDay, entryHour, totalTimesAndAverages);

        }

        return filteredProcesses;
    }


    /**
     * Filters the processes based on the test input.
     *
     * @param day       The day to filter by. If null, all days are included.
     * @param hour      The hour to filter by. If null, all hours are included.
     * @param office    The office to filter by. If null, all offices are included.
     * @param userName  The user name to filter by. If null, all user names are included.
     * @param documents The documents to filter from the test cases provided.
     * @return The filtered processes.
     */

    private static List<ProcessTime> filterTheProcesses(Integer day, Integer hour, String office, String userName,
                                                        Map<String, List<ProcessTime>> documents) {
        return documents.entrySet().stream()
                .filter(entry -> {
                    String[] keyParts = entry.getKey().split("_");
                    String entryOffice = keyParts[0];
                    String entryUserName = keyParts[1];
                    int entryDay = Integer.parseInt(keyParts[2]);

                    return (day == null || entryDay == day) &&
                            (hour == null || entry.getValue().stream().anyMatch(processTime
                                    -> processTime.getHour() == hour)) &&
                            (office == null || entryOffice.equals(office)) &&
                            (userName == null || entryUserName.equals(userName));
                })
                .flatMap(entry -> {
                    String[] keyParts = entry.getKey().split("_");
                    String entryOffice = keyParts[0];
                    String entryUserName = keyParts[1];
                    int entryDay = Integer.parseInt(keyParts[2]);

                    return entry.getValue().stream()
                            .peek(processTime -> {
                                processTime.setOffice(entryOffice);
                                processTime.setUserName(entryUserName);
                                processTime.setDay(entryDay);
                            });
                })
                .toList();
    }

    /**
     * Calculates the total times and averages for the given processes.
     *
     * @param processesInGroup The processes to calculate the times for.
     * @return The total times and averages.
     */
    private Map<String, Long> calculateTotalTimesAndAverages(List<ProcessTime> processesInGroup) {
        long totalScanTime = 0, totalSaveTime = 0, totalLoadTime = 0;
        int count = processesInGroup.size();

        for (ProcessTime process : processesInGroup) {
            Map<String, Long> times = process.calculateTimes();
            totalScanTime += times.getOrDefault("scanTime", 0L);
            totalSaveTime += times.getOrDefault("saveTime", 0L);
            totalLoadTime += times.getOrDefault("loadTime", 0L);
        }

        long avgScanTime = count == 0 ? 0 : totalScanTime / count;
        long avgSaveTime = count == 0 ? 0 : totalSaveTime / count;
        long avgLoadTime = count == 0 ? 0 : totalLoadTime / count;

        return Map.of(
                "count", (long) count,
                "avgScanTime", avgScanTime,
                "avgSaveTime", avgSaveTime,
                "avgLoadTime", avgLoadTime
        );
    }


    /**
     * @param officeName
     * @param userName
     * @param day
     * @param hour
     * @param totalTimesAndAverages
     */
    private void printReport(String officeName, String userName, Integer day, Integer hour,
                             Map<String, Long> totalTimesAndAverages) {
        long count = totalTimesAndAverages.get("count");
        long avgScanTime = totalTimesAndAverages.get("avgScanTime");
        long avgSaveTime = totalTimesAndAverages.get("avgSaveTime");
        long avgLoadTime = totalTimesAndAverages.get("avgLoadTime");

        reportPrinter.printSummary((int) count, avgScanTime, avgSaveTime, avgLoadTime);
        reportPrinter.printDetails(officeName, userName, day, hour, (int) count, avgScanTime, avgSaveTime, avgLoadTime);
    }

    /**
     * @param day
     * @param hour
     * @param office
     * @param userName
     * @return
     */
    public int getNumberOfDocumentsProcessed(Integer day, Integer hour, String office, String userName) {
        List<ProcessTime> filteredDocuments = calculateAverages(day, hour, office, userName);
        return filteredDocuments.size();
    }

}
