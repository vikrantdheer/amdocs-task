package com.task1.amdocs;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ReportPrinter implements com.task1.amdocs.Printer {

    @Override
    public void printSummary(int count, long avgScanTime, long avgSaveTime, long avgLoadTime) {
        System.out.println("Summary");
        System.out.println("Avrg time to scan: " + avgScanTime + " ms");
        System.out.println("Avrg time to save img: " + avgSaveTime + " ms");
        System.out.println("Avrg time to show image: " + avgLoadTime + " ms");
        System.out.println("All documents scanned: " + count);
    }

    @Override
    public void printDetails(String office, String userName, Integer day, Integer hour, int count, long avgScanTime,
                             long avgSaveTime, long avgLoadTime) {
        System.out.println("Detail:");
        if (office != null) {
            System.out.println("Office " + office + ": " + count + " documents scanned");
        }
        if (userName != null) {
            System.out.println("User " + userName + ": " + count + " documents scanned");
        }
        if (day != null) {
            System.out.println("Day: " + day + ". " + count + " documents scanned");
        }
        if (hour != null) {
            System.out.println("Hour: " + hour + ". " + count + " documents scanned");
            System.out.println("Avrg time to scan: " + avgScanTime + " ms");
            System.out.println("Avrg time to save img: " + avgSaveTime + " ms");
            System.out.println("Avrg time to show image: " + avgLoadTime + " ms");
        }
        System.out.println("----------------------------------------------------------------");
    }
}
