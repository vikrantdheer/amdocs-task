package com.task1.amdocs;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Data
public class ProcessTime {
    private LocalTime scanStartTime;
    private LocalTime scanEndTime;
    private LocalTime saveStartTime;
    private LocalTime saveEndTime;
    private LocalTime loadStartTime;
    private LocalTime loadEndTime;
    private String office;
    private String userName;
    private int day;
    private int hour;

    public ProcessTime() {
        scanStartTime = scanEndTime = saveStartTime = saveEndTime = loadStartTime = loadEndTime = null;
    }

    public Map<String, Long> calculateTimes() {
        Map<String, Long> times = new HashMap<>();
        if (scanStartTime != null && scanEndTime != null) {
            times.put("scanTime", ChronoUnit.MILLIS.between(scanStartTime, scanEndTime));
        }
        if (saveStartTime != null && saveEndTime != null) {
            times.put("saveTime", ChronoUnit.MILLIS.between(saveStartTime, saveEndTime));
        }
        if (loadStartTime != null && loadEndTime != null) {
            times.put("loadTime", ChronoUnit.MILLIS.between(loadStartTime, loadEndTime));
        }
        return times;
    }

    public int getHour() {
        return scanStartTime.getHour();
    }

}
