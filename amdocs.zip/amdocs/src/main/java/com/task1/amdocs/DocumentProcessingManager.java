package com.task1.amdocs;

import java.util.List;
import java.util.Map;

public interface DocumentProcessingManager {
    Map<String, List<ProcessTime>> getDocuments();
}
